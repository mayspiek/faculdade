public final class ClasseFinal {
    public int id = 127;

    public ClasseFinal() {
        System.out.println("Classe que não pode ser extendida.");        
    }
}
