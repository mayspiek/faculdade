public class HerdaClassePai extends ClasseFinal {
    
}
