public class UsaClasseFInal {
    public static void main(String[] args) {
        ClasseFinal f1 = new ClasseFinal();
        System.out.println("id é " + f1.id);
    }
}
